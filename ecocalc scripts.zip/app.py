from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
import datetime
import math

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///climate.db'
db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    carbon_footprints = db.relationship('CarbonFootprint', backref='user', lazy=True)

class CarbonFootprint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.datetime.utcnow)
    total = db.Column(db.Float, nullable=False)
    transportation = db.Column(db.Float)
    energy = db.Column(db.Float)
    food = db.Column(db.Float)
    waste = db.Column(db.Float)

class SolutionAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    action_type = db.Column(db.String(120), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.datetime.utcnow)
    impact = db.Column(db.Float)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculator', methods=['GET', 'POST'])
def calculator():
    if request.method == 'POST':
        # Calculate carbon footprint
        transport = float(request.form.get('transport', 0))
        energy = float(request.form.get('energy', 0))
        food = float(request.form.get('food', 0))
        waste = float(request.form.get('waste', 0))
        
        total = transport + energy + food + waste
        
        if 'user_id' in session:
            new_entry = CarbonFootprint(
                user_id=session['user_id'],
                total=total,
                transportation=transport,
                energy=energy,
                food=food,
                waste=waste
            )
            db.session.add(new_entry)
            db.session.commit()
        
        return render_template('calculator.html', calculated=True, total=total, 
                             transport=transport, energy=energy, food=food, waste=waste)
    
    return render_template('calculator.html', calculated=False)

@app.route('/solutions')
def solutions():
    # List of actionable solutions
    solution_categories = [
        {
            'name': 'Energy',
            'actions': [
                {'title': 'Switch to renewable energy', 'impact': 900, 'desc': 'Reduce your carbon footprint by 900 kg CO2/year'},
                {'title': 'Install solar panels', 'impact': 1500, 'desc': 'Average household can save 1.5 tons CO2/year'},
                {'title': 'Use energy-efficient appliances', 'impact': 300, 'desc': 'Save 300 kg CO2/year'}
            ]
        },
        {
            'name': 'Transportation',
            'actions': [
                {'title': 'Use public transportation', 'impact': 2000, 'desc': 'Save up to 2 tons CO2/year'},
                {'title': 'Switch to electric vehicle', 'impact': 2500, 'desc': 'Reduce emissions by 2.5 tons CO2/year'},
                {'title': 'Bike or walk for short trips', 'impact': 300, 'desc': 'Save 300 kg CO2/year'}
            ]
        },
        {
            'name': 'Food',
            'actions': [
                {'title': 'Reduce meat consumption', 'impact': 800, 'desc': 'Vegetarian diet saves 800 kg CO2/year'},
                {'title': 'Buy local produce', 'impact': 200, 'desc': 'Reduce food miles by 200 kg CO2/year'},
                {'title': 'Reduce food waste', 'impact': 400, 'desc': 'Save 400 kg CO2/year'}
            ]
        }
    ]
    return render_template('solutions.html', solutions=solution_categories)

@app.route('/community')
def community():
    # In a real app, this would fetch from database
    community_actions = [
        {'user': 'EcoWarrior22', 'action': 'Installed solar panels', 'impact': 1500, 'date': '2023-05-15'},
        {'user': 'GreenThumb', 'action': 'Started composting', 'impact': 200, 'date': '2023-05-10'},
        {'user': 'ClimateHero', 'action': 'Switched to EV', 'impact': 2500, 'date': '2023-05-05'},
        {'user': 'SustainableSam', 'action': 'Went vegetarian', 'impact': 800, 'date': '2023-04-28'}
    ]
    return render_template('community.html', actions=community_actions)

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    footprints = CarbonFootprint.query.filter_by(user_id=user.id).order_by(CarbonFootprint.date.desc()).limit(5).all()
    actions = SolutionAction.query.filter_by(user_id=user.id).order_by(SolutionAction.date.desc()).limit(5).all()
    
    total_reduction = sum(action.impact for action in actions) if actions else 0
    
    return render_template('dashboard.html', 
                         user=user, 
                         footprints=footprints, 
                         actions=actions,
                         total_reduction=total_reduction)

# Auth routes would be added here (login, register, logout)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)